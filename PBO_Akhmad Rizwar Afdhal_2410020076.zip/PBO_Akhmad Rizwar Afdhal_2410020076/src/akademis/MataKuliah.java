package akademis;

public class MataKuliah {

    private String kode_mk;
    private String nama_mk;

    public MataKuliah(String kode_mk, String nama_mk) {
        this.kode_mk = kode_mk;
        this.nama_mk = nama_mk;
    }

    public String getKode_mk() {
        return kode_mk;
    }

    public String getNama_mk() {
        return nama_mk;
    }

    public void setKode_mk(String kode_mk) {
        this.kode_mk = kode_mk;
    }

    public void setNama_mk(String nama_mk) {
        this.nama_mk = nama_mk;
    }
}