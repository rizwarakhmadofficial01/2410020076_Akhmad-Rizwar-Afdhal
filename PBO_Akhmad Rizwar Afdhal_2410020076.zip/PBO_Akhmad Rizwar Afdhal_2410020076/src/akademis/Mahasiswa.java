package akademis;

public class Mahasiswa {

    // 1. ATRIBUT (sesuai papan)
    private String npm;
    private String nama;
    private double ipk;
    private int semester;

    // 2. CONSTRUCTOR (untuk isi data awal)
    public Mahasiswa(String npm, String nama, double ipk, int semester) {
        this.npm = npm;
        this.nama = nama;
        this.ipk = ipk;
        this.semester = semester;
    }

    // 3. GETTER (ambil data)
    public String getNpm() {
        return npm;
    }

    public String getNama() {
        return nama;
    }

    public double getIpk() {
        return ipk;
    }

    public int getSemester() {
        return semester;
    }

    // 4. SETTER (ubah data)
    public void setNpm(String npm) {
        this.npm = npm;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setIpk(double ipk) {
        this.ipk = ipk;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }
}