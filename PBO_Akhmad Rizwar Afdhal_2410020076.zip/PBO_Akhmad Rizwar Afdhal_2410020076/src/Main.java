import akademis.Mahasiswa;
import akademis.MataKuliah;

public class Main {

    public static void main(String[] args) {

        // 1. BUAT OBJECT MAHASISWA
        Mahasiswa mhs = new Mahasiswa(
            "2410020076",
            "Akhmad Rizwar Afdhal",
            3.75,
            4
        );

        // 2. BUAT OBJECT MATAKULIAH
        MataKuliah mk = new MataKuliah(
            "PBO001",
            "Pemrograman Berorientasi Objek"
        );

        // 3. TAMPILKAN DATA
        System.out.println("=== DATA MAHASISWA ===");
        System.out.println("NPM       : " + mhs.getNpm());
        System.out.println("Nama      : " + mhs.getNama());
        System.out.println("IPK       : " + mhs.getIpk());
        System.out.println("Semester  : " + mhs.getSemester());

        System.out.println("\n=== DATA MATA KULIAH ===");
        System.out.println("Kode MK   : " + mk.getKode_mk());
        System.out.println("Nama MK   : " + mk.getNama_mk());

        System.out.println("\nKelas : SI 4A Reguler Banjarbaru");
    }
}